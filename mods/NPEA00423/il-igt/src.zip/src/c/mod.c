extern int worldUpdateTime;

void main_loop() {
    worldUpdateTime++;
    return;
}