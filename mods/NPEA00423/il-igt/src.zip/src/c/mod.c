extern int worldUpdateTime;
int framesSinceReload;

void incrBoth() {
    worldUpdateTime++;
    framesSinceReload++;
}

void resetTimer() {
    framesSinceReload = 0;
}

void incrTimer() {
    framesSinceReload++;
    return;
}

void writeTimer() {
    worldUpdateTime = framesSinceReload;
}