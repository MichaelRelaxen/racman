# Macro for creating raw patches.
.macro PATCH addr, name, instr:vararg
	.section .hook.\name 
	\instr
.endm 

# --- Entrypoints ---
# Asdfasdfasdfasdf
PATCH 0x1d102c, paused_game_hook, bl main_loop
