# Macro for creating raw patches.
.macro PATCH addr, name, instr:vararg
	.section .hook.\name 
	\instr
.endm 

# --- Entrypoints ---
PATCH 0x1d102c, pause_hook, bla incrTimer
PATCH 0x1c7b98, reset_hook, bla resetTimer
PATCH 0x1d14c0, incr1_hook, bla incrBoth
PATCH 0x2b254c, incr2_hook, bla incrBoth
PATCH 0x2b4488, incr3_hook, bla incrBoth
PATCH 0x378a60, write_hook, bla writeTimer