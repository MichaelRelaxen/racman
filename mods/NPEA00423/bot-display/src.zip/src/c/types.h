typedef unsigned char undefined;
typedef unsigned char byte;
typedef unsigned int dword;
typedef long long longlong;
typedef unsigned long long qword;
typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned long long ulonglong;
typedef unsigned char undefined1;
typedef unsigned short undefined2;
typedef unsigned int undefined4;
typedef unsigned long long undefined8;
typedef unsigned short ushort;
typedef unsigned short word;
typedef struct Moby Moby, *PMoby;
typedef unsigned char    bool;


/* WARNING! conflicting data type names: /eboot.bin.h/uchar - /uchar */

typedef uchar uint8_t;

typedef char __int8_t;

typedef __int8_t int8_t;


/* WARNING! conflicting data type names: /types.h/ushort - /ushort */

typedef ushort __uint16_t;

typedef __uint16_t uint16_t;

typedef ulonglong uint64_t;

typedef uint uint32_t;

typedef int int32_t;

typedef struct {
    float x;
    float y;
    float z;
    float w;
} Vec4;


typedef struct  {
    Vec4 forward;
    Vec4 right;
    Vec4 up;
} mtx3;

typedef struct {
    void* grid;
    float pad1;
    float pad2;
    float pad3;
    int count;
    int damage_next;
    Moby* pMoby;
    int poly;
    Vec4 ip;
    Vec4 push;
    Vec4 normal;
    Vec4 forward;
    Vec4 right;
    Vec4 up;
} CollOutput;

typedef struct {
	unsigned int start_color;
	unsigned int transition_color;
	short unk;
	short size;
	unsigned int frames;
} ChargeParticle;

typedef struct Moby {
    Vec4 bSphere;
    Vec4 pos;
    char state;
    unsigned char group;
    char mClass;
    char alpha;
    struct MobyClass *pClass;
    Moby *pChain;
    char collDamage;
    signed char deathCnt;
    short unsigned int occlIndex;
    char updateDist;
    char drawn;
    short int drawDist;
    short unsigned int modeBits;
    short unsigned int modeBits2;
    uint64_t lights;
    struct MobySeq *animSeq;
    float animSeqT;
    float animSpeed;
    short int animIScale;
    short int poseCacheEntryIndex;
    struct MobyAnimLayer *animLayers;
    char animSeqId;
    char animFlags;
    char lSeq;
    char jointCnt;
    struct mtx4 *jointCache;
    struct Manipulator *pManipulator;
    int glow_rgba;
    char lod_trans;
    char lod_trans2;
    char metal;
    char subState;
    char prevState;
    char stateType;
    short unsigned int stateTimer;
    char soundTrigger;
    char soundDesired;
    short int soundChannel;
    float scale;
    short unsigned int bangles;
    char shadow;
    char shadow_index;
    float shadow_plane;
    float shadow_range;
    Vec4 lSphere;
    void *netObject;
    short int updateID;
    short int spad0;
    int *collData;
    int collActive;
    unsigned int collCnt;
    char grid_min_x;
    char grid_min_y;
    char grid_max_x;
    char grid_max_y;
    void *pUpdate;
    void *pVar;
    char mission;
    char pad;
    short int UID;
    short int bolts;
    short unsigned int xp;
    struct MobyInstance *pParent;
    short int oClass;
    char triggers;
    char standarddeathcalled;
    mtx3 rMtx;
    Vec4 rot;
} Moby;

typedef struct BoltVars BoltVars;

struct BoltVars {
    int32_t bolt_slot;
    int32_t cuboid1;
    int32_t cuboid2;
    byte idc1;
    byte skip_animation;
    undefined1 idc2[114];
} __attribute__((packed));

typedef enum CommandTypes {
    CMD_NONE=0,
    CMD_REGROUP=1,
    CMD_DESTROY=2,
    CMD_HEAL=3,
    CMD_EMP=4,
    CMD_HACK=5,
    CMD_GRIND_CABLE=6,
    CMD_DRAW_FIRE=7,
    CMD_STAND=8,
    CMD_REVIVE=9,
    CMD_BOLT_CRANK=10,
    CMD_SHIELD=11,
    CMD_LIMIT_BREAK=12,
    CMD_COUNT=13
} CommandTypes;

typedef struct {
    enum CommandTypes commandType;
    Moby *pMoby;
    int playerNum;
    int timeIssued;
    Moby *pTaker;
    int spot;
} IssuedCommand;

typedef struct {
    bool initialized;
    bool isLocked;
    bool ignoreVehicles;
    bool botActive;
    int lastRoleUpdate;
    int nextIndex;
    float dbgHitPoints;
    unsigned char dbgAttackDamage[4];
    int lastAttackMsg;
    int lastVO;
    int numAttacking;
    int numSighted;
    Moby *pBehaviourOverride;
    int numEffectors;
    int empCnt;
    int nextSpeaker;
    int lastMission;
    int killVOTime;
    int empVOTime;
    int victoryVOTime;
    int reviveVOTime;
    int attackedVOTime;
    int completeVOTime;
    int damagedVOTime;
    int deathVOTime;
    int attackingVOTime;
    int affirmVOTime;
    Vec4 avgAttackPos;
    Vec4 formationOverride;
    Vec4 movementOverride;
    Vec4 heroMovement;
    Vec4 heroProjection;
    Vec4 formationPos[4];
    Vec4 teleportPos;
    Moby *pEffectorList[48];
    IssuedCommand *botCommands[4];
    Moby *pBot[4];
    unsigned int botFlags[4];
    int heroOnElevator;
    bool botAbilities[17];
    undefined field40_0x205;
    undefined field41_0x206;
    undefined field42_0x207;
    undefined field43_0x208;
    undefined field44_0x209;
    undefined field45_0x20a;
    undefined field46_0x20b;
    undefined field47_0x20c;
    undefined field48_0x20d;
    undefined field49_0x20e;
    undefined field50_0x20f;
} Bot_Communication;

typedef struct {
    float hitPoints;
    int maxHitPoints;
    unsigned char attackDamage[6];
    short int hitCount;
    int flags;
    float targetHeight;
    Moby *mobyThatHurtMeLast;
    float camPushDist;
    float camPushHeight;
    short int damageCounter;
    short int empTimer;
    short int infectedTimer;
    short int invincTimer;
    short int bogeyType;
    short int team;
    char lookAtMeDist;
    char lookAtMePriority;
    char lookAtMeZOfsIn8ths;
    char lookAtMeJoint;
    char lookAtMeExpression;
    char lockOnPriority;
    char soundType;
    char targetRadiusIn8ths;
    char noAutoTrack;
    char trackSpeedInMps;
    char camModOverride;
    char destroyMe;
    char morphoraySpecial;
    char headJoint;
    char hitByContinuous;
    char infected;
    char empFxTimer;
    char weaponTargetedOnMe;
    char isOrganic;
    signed char bundleIndex;
    char bundleDamage;
    char firedAt;
    char weaponThatHurtMeLast;
    char invalidTarget;
    int maxDifficultySlotted;
    int curDifficultySlotted;
    Moby *pTargettedByBogeys[8];
    Moby *mobyThatFiredAtMe;
    int targetShadowMask;
    int damageTypes;
    int padA;
    float morphDamage;
    float freezeDamage;
    float infectDamage;
    float lastDamage;
} TargetVars;