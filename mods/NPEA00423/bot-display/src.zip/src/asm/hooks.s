# Macro for creating raw patches.
.macro PATCH addr, name, instr:vararg
	.section .hook.\name 
	\instr
.endm 

# --- Entrypoints ---
# Asdfasdfasdfasdf
PATCH 0x70719c, controller_hook, bl side_loop
PATCH 0x0bac18, draw_hud_hook, bl main_loop
