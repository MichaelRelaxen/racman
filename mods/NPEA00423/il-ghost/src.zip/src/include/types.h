typedef unsigned char undefined;
typedef unsigned char byte;
typedef unsigned int dword;
typedef long long longlong;
typedef unsigned long long qword;
typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned long long ulonglong;
typedef unsigned char undefined1;
typedef unsigned short undefined2;
typedef unsigned int undefined4;
typedef unsigned long long undefined8;
typedef unsigned short ushort;
typedef unsigned short word;
typedef struct Moby Moby, *PMoby;
// typedef unsigned char    bool;


/* WARNING! conflicting data type names: /eboot.bin.h/uchar - /uchar */

typedef uchar uint8_t;

typedef char __int8_t;

typedef __int8_t int8_t;


/* WARNING! conflicting data type names: /types.h/ushort - /ushort */

typedef ushort __uint16_t;

typedef __uint16_t uint16_t;

typedef ulonglong uint64_t;

typedef uint uint32_t;

typedef int int32_t;

typedef struct {
    float x;
    float y;
    float z;
    float w;
} Vec4;


typedef struct  {
    Vec4 forward;
    Vec4 right;
    Vec4 up;
} mtx3;

typedef struct {
    void* grid;
    float pad1;
    float pad2;
    float pad3;
    int count;
    int damage_next;
    Moby* pMoby;
    int poly;
    Vec4 ip;
    Vec4 push;
    Vec4 normal;
    Vec4 forward;
    Vec4 right;
    Vec4 up;
} CollOutput;

typedef struct {
	unsigned int start_color;
	unsigned int transition_color;
	short unk;
	short size;
	unsigned int frames;
} ChargeParticle;

typedef struct Moby {
    Vec4 bSphere;
    Vec4 pos;
    char state;
    unsigned char group;
    char mClass;
    char alpha;
    struct MobyClass *pClass;
    Moby *pChain;
    char collDamage;
    signed char deathCnt;
    short unsigned int occlIndex;
    char updateDist;
    char drawn;
    short int drawDist;
    short unsigned int modeBits;
    short unsigned int modeBits2;
    uint32_t color;
    uint32_t lights;
    // uint64_t lights;
    struct MobySeq *animSeq;
    float animSeqT;
    float animSpeed;
    short int animIScale;
    short int poseCacheEntryIndex;
    struct MobyAnimLayer *animLayers;
    char animSeqId;
    char animFlags;
    char lSeq;
    char jointCnt;
    struct mtx4 *jointCache;
    struct Manipulator *pManipulator;
    int glow_rgba;
    char lod_trans;
    char lod_trans2;
    char metal;
    char subState;
    char prevState;
    char stateType;
    short unsigned int stateTimer;
    char soundTrigger;
    char soundDesired;
    short int soundChannel;
    float scale;
    short unsigned int bangles;
    char shadow;
    char shadow_index;
    float shadow_plane;
    float shadow_range;
    Vec4 lSphere;
    void *netObject;
    short int updateID;
    short int spad0;
    int *collData;
    int collActive;
    unsigned int collCnt;
    char grid_min_x;
    char grid_min_y;
    char grid_max_x;
    char grid_max_y;
    void *pUpdate;
    void *pVar;
    char mission;
    char pad;
    short int UID;
    short int bolts;
    short unsigned int xp;
    struct MobyInstance *pParent;
    short int oClass;
    char triggers;
    char standarddeathcalled;
    mtx3 rMtx;
    Vec4 rot;
} Moby;

typedef enum gameMode_t {
    GAME_MODE_NONE=-2,
    GAME_MODE_DEBUG=-1,
    GAME_MODE_NORMAL=0,
    GAME_MODE_MOVIE=1,
    GAME_MODE_SCENE=2,
    GAME_MODE_PAUSE=3,
    GAME_MODE_FREEZE=4,
    GAME_MODE_VENDOR=5,
    GAME_MODE_SPACE=6,
    GAME_MODE_PUZZLE=7,
    GAME_MODE_WEAPON_UPGRADE=8,
    GAME_MODE_CREDITS=9,
    GAME_MODE_LOBBY=10,
    GAME_MODE_FLYBY=11,
    GAME_MODE_THERMAL=12,
    GAME_MODE_PRE_LOBBY_MEMCARD_LOAD=13,
    GAME_MODE_PRE_LOBBY=14,
    GAME_MODE_WAIT_FOR_MPSTART=15,
    GAME_MODE_EXEC_MP_MEMCARD_COMMAND=16,
    GAME_MODE_IOP_DEBUG=17,
    GAME_MODE_MAX=18
} gameMode_t;

typedef struct HudComplete_CommonData_s HudComplete_CommonData_s, *PHudComplete_CommonData_s;
typedef struct ST_MissionData ST_MissionData, *PST_MissionData;
typedef struct Stat_s Stat_s, *PStat_s;
typedef struct DataSourceImageBuffer DataSourceImageBuffer, *PDataSourceImageBuffer;
typedef struct ST_MissionRewardData ST_MissionRewardData, *PST_MissionRewardData;
typedef undefined1 *StatFill_f;
typedef struct DataSourceImageBuffer__vtable DataSourceImageBuffer__vtable, *PDataSourceImageBuffer__vtable;

typedef enum ST_RewardType {
    ST_RWRD_BADGE=0,
    ST_RWRD_GADGET=1,
    ST_RWRD_BSC_MOD=2,
    ST_RWRD_PFX_MOD=3,
    ST_RWRD_WPN_MOD=4,
    ST_RWRD_ARMOR=5,
    ST_RWRD_LEVEL=6,
    ST_RWRD_TOURNAMENT=7,
    ST_RWRD_NONE=8,
    ST_RWRD_TOTAL_TYPES=9
} ST_RewardType;

struct DataSourceImageBuffer {
    int m_state; /* Inherited from DataSource */
    struct DataSourceImageBuffer__vtable *__vtable; /* Inherited from DataSource */
};

struct ST_MissionRewardData {
    enum ST_RewardType iType;
    int iSubType;
    int iIcon;
    unsigned int iColor;
    int iPlate;
    int iName;
};

struct DataSourceImageBuffer__vtable {
    undefined field0_0x0;
    undefined field1_0x1;
    undefined field2_0x2;
    undefined field3_0x3;
    undefined field4_0x4;
    undefined field5_0x5;
    undefined field6_0x6;
    undefined field7_0x7;
    void* RequestData;
    void* AbortLastRequest;
    void* Update;
    void* GetType;
    void* GetData;
};

struct Stat_s {
    int iVal;
    int iMax;
    uchar zVal[18];
    undefined field3_0x1a;
    undefined field4_0x1b;
    StatFill_f fcFill;
    int iSound;
};

struct ST_MissionData {
    int bSuccess;
    int iTime;
    int iBolts;
    int vKills[2];
    int iRewardBolts;
    int iRewardPoints;
    int iSkillPoints;
    int iSkillPointMax;
    int iRewards;
    struct ST_MissionRewardData vRewards[2];
    int iXP;
    int vShotsThatHit[2];
    int vShotsThatMissed[2];
    int vDeaths[2];
};

struct HudComplete_CommonData_s {
    int iState;
    int iShown;
    struct ST_MissionData cdData;
    int iDelay;
    int iSubState;
    int iStats;
    struct Stat_s vStats[6];
    char bSound;
    undefined field8_0x161;
    undefined field9_0x162;
    undefined field10_0x163;
    int iPrizes;
    struct DataSourceImageBuffer *vPrizeBuffers[3];
    struct DataSourceImageBuffer *pPrizeBuffer;
    struct DataSourceImageBuffer *pBackBuffer;
};

typedef enum FontAlignment {
    TOP_LEFT=0,
    TOP_CENTER=1,
    TOP_RIGHT=2,
    CENTER_LEFT=3,
    CENTER_CENTER=4,
    CENTER_RIGHT=5,
    BOTTOM_LEFT=6,
    BOTTOM_CENTER=7,
    BOTTOM_RIGHT=8
} FontAlignment;

