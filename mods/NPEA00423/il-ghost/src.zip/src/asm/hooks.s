# Macro for creating raw patches.
.macro PATCH addr, name, instr:vararg
	.section .hook.\name 
	\instr
.endm 

# NOP unwanted elements in endscreen
PATCH 0x037bad4, nop_hud_skill, ori r0,r0,0x0
PATCH 0x037ba88, nop_hud_bolts, ori r0,r0,0x0

# --- Entrypoints ---
# Random fucking hook I found
PATCH 0x070734c, input_hook, bla mainLoop