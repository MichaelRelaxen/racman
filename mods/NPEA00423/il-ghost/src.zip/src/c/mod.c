#include "game.h"
#include "types.h"

#define BLUE 0xFFFF8080

// File paths
#define TEMP_RECORD_PATH "/dev_hdd0/game/NPEA00423/USRDIR/temp_record.gf"
#define PB_PATH_FORMAT   "/dev_hdd0/game/NPEA00423/USRDIR/pb_level%d_mission%d.gf"

// Ghost
#define GHOST_VISIBILITY 45

// States
#define STATE_STOP   0
#define STATE_WAIT   1
#define STATE_RECORD 2

////////////////////////////////////////////////////////////////////////////////
// Types
////////////////////////////////////////////////////////////////////////////////

typedef struct __attribute__((packed)) {
	Vec4 bSphere;   // 16
	Vec4 pos;       // 16
	mtx3 rMtx;      // 48 mtx3
    Vec4 rot;       // 64 Vec4
	char asdf[3];   // 3 padding
	char animSeqId; // 1
	uint32_t eof;   // 4
} ghostFile;

typedef struct {
	int fd;
	uint64_t nread;
} sys_fs;

////////////////////////////////////////////////////////////////////////////////
// Externs
////////////////////////////////////////////////////////////////////////////////

void memcpy(void* dst, void* src, int size);
void memset(void* destination, char val, int size);
void printf(char* fmt, ...);
void sprintf(char* dst, char* fmt, ...);

extern Moby* CreateMoby(int oClass);
extern void UpdateMobyAnim(Moby* pMoby);
extern void AnimEvaluateResolve(Moby* pMoby);
extern void PostUpdateMoby(Moby* pMoby);
extern void MB_transAnim(double frm, Moby *pMoby, int seq, undefined8 param_4, int steps);
// extern uint button_bitmask;
extern unsigned char* g_Hero;

extern Moby* MobyInstanceEnd;
extern Moby* MobyInstancePermEnd;
extern Moby* MobyInstances;

extern int currentLevel;
extern int currentMission;
extern int worldUpdateTime;
extern gameMode_t gameMode;
extern HudComplete_CommonData_s HCD;
extern uint pressedButtons;

extern void FontPrint(
    double x,        // f1
    double y,        // f2
    double scaleX,   // f3
    double scaleY,   // f4
    double unk1,     // f5 — pass 0.0
    double unk2,     // f6 — pass 0.0
    void* unk,       // r3 — can be NULL
    void* fontRes,   // r4 — font resource or NULL
    uint32_t color,  // r5 — ARGB
    char* text,      // r6 — string pointer
    int maxLen,      // r7 — pass -1
    int unk3,        // r8 — pass 0
    int length,      // r9 — string length
    FontAlignment fa // r10 — pass 1
);

////////////////////////////////////////////////////////////////////////////////
// Globals
////////////////////////////////////////////////////////////////////////////////

char pbPath[128];
Moby* ghostMoby;

uint32_t ghostState;
int savePbState;

sys_fs f_playback;
sys_fs f_recording;

int oldButtonBitmask;
int pbTime;
int storedGameState;
// uchar needsDrawing;

////////////////////////////////////////////////////////////////////////////////
// Misc
////////////////////////////////////////////////////////////////////////////////

int generate_timer(char* buf, int frames) {
    reserve_stack(128);
    int hours = frames / (3600 * 60);
    int minutes = frames % (3600 * 60) / (60 * 60);
    int seconds = frames % (60 * 60) / 60;
    int cs = (frames % 60) * (100.f / 60.f);
	
    // sprintf(buf, "%d : %.2d . %.2d", minutes, seconds, cs);
	// if(minutes)
        sprintf(buf, "%.2d:%.2d.%.2d", minutes, seconds, cs);
	// else 
		// sprintf(buf, "%d.%.2d", seconds, cs);
}

// void drawHook() {
//     reserve_stack(256);

//     char buf[16];
//     if (needsDrawing) {
//         needsDrawing = 0;

//         sprintf(buf, "\x12 Clear");
//         FontPrint(258.0, 474.0, 1.1103, 1.1103, 0.0, 0.0, NULL, NULL, 0x40000000, buf, -1, 0, 0x1D5C, 1);
//         FontPrint(256.0, 472.0, 1.1103, 1.1103, 0.0, 0.0, NULL, NULL, 0x80D0D0D0, buf, -1, 0, 0x0440, 1);
//     }
// }

Moby* getRatchetMoby() {
    return (Moby*)(*(unsigned int*)(g_Hero + 0x2EF0));
} 

////////////////////////////////////////////////////////////////////////////////
// Ghost
////////////////////////////////////////////////////////////////////////////////

void cleanupFiles() {
    if(f_playback.fd) {
        syscall(sys_fs_close, f_playback.fd);
        f_playback.fd = 0;
        }
    if(f_recording.fd) {
        syscall(sys_fs_close, f_recording.fd);
        f_recording.fd = 0;
    }
}

void savePBWithTime(int frames, int planet, int mission) {
    reserve_stack(512);
    int fd_read, fd_write;
    uint64_t nread, nwritten;
    char pb_save_path[128];
    
    // format pb path for this specific planet
    sprintf(pb_save_path, PB_PATH_FORMAT, planet, mission);
    
    syscall(sys_fs_open, TEMP_RECORD_PATH, READ_ONLY_FLAGS, &fd_read, 0, 0, 0);
    syscall(sys_fs_open, pb_save_path, WRITE_FLAGS, &fd_write, 0, 0, 0);
    
    // Write PB time at the start
    syscall(sys_fs_write, fd_write, &frames, sizeof(int), &nwritten);
    
    // Copy all frames
    ghostFile buf;
    while(1) {
        syscall(sys_fs_read, fd_read, &buf, sizeof(ghostFile), &nread);
        syscall(sys_fs_write, fd_write, &buf, sizeof(ghostFile), &nwritten);
        if(buf.eof == 0xDEADDEAD)
            break;
    }
    
    syscall(sys_fs_close, fd_read);
    syscall(sys_fs_close, fd_write);
    
    pbTime = frames;
}

int ghostInit() {
    reserve_stack(512);
    Moby* ratchetMoby = getRatchetMoby();

    ghostMoby = CreateMoby(9207);
    if (ghostMoby == (Moby*)0x0) {
        return -1;
    }

    // Rotation matrix needs to be copied when initializing or else he wont be visible.
    ghostMoby->rMtx = ratchetMoby->rMtx;
    
    // Set perm properties.
    ghostMoby->color = 0;
    ghostMoby->lights = 0;
    ghostMoby->alpha = (GHOST_VISIBILITY * 128) / 100;
    ghostMoby->drawDist = 0xFFF;
    ghostMoby->drawn = 1;
    
    // Disable collision
    ghostMoby->collActive = 0;
    ghostMoby->collData = 0;
    ghostMoby->collCnt = 0;

    // disable effector check(?) fixes a crash
    ghostMoby->modeBits &= ~0x20;
    
    // todo: look more into how shadows work.
    ghostMoby->shadow_index = ratchetMoby->shadow_index;
    ghostMoby->shadow_range = ratchetMoby->shadow_range;
    ghostMoby->shadow_plane = ratchetMoby->shadow_plane;

    ghostMoby->pos = ratchetMoby->pos;
    ghostMoby->pos.x += 2;

    return 0;
}

void ghostPlayback(Moby* moby, ghostFile* ghost) {
	reserve_stack(512);
	syscall(sys_fs_read, f_playback.fd, ghost, sizeof(ghostFile), &f_playback.nread);

	if(!moby) {
		return;
    }
	
	// Ghost has finished so we need to close the playback
	if(ghost->eof == 0xDEADDEAD) {
		syscall(sys_fs_close, f_playback.fd);
		f_playback.fd = 0;
        ghostMoby->alpha = 0;
		ghostMoby = 0;
	} else {
		moby->bSphere   = ghost->bSphere;
		moby->pos       = ghost->pos;
		moby->rMtx      = ghost->rMtx;
        moby->rot       = ghost->rot;
		moby->scale     = getRatchetMoby()->scale;
        // Only animate when in-game (fixes a sound bug)
        if (gameMode == GAME_MODE_NORMAL) {
            moby->animSeqId = ghost->animSeqId;
            MB_transAnim(1.0, moby, ghost->animSeqId, 0, 5);
        }
        // These don't seem to do anything
        // UpdateMobyAnim(moby);
        // AnimEvaluateResolve(moby);
        // PostUpdateMoby(moby);
	}
}

void ghostRun() {
    reserve_stack(512);

	ghostFile g_Frame[sizeof(ghostFile)];
	
	switch(ghostState) {
		case STATE_WAIT:
			// Just close in case.
            cleanupFiles();
            break;
			
		case STATE_RECORD:
			// null moby check so we dont crash.
			if(!getRatchetMoby() || worldUpdateTime < 3) {
				break;
			}
			
			// stop recording after 5 minutes in case user went afk
			if (worldUpdateTime > 18000) {
                ghostState = STATE_STOP;
				cleanupFiles();
			}
			
 			if(!savePbState) {
                Moby* ratchetMoby = getRatchetMoby();
				// Write this frame to our temp recording file.
				ghostFile recording[sizeof(ghostFile)];
				recording->bSphere   = ratchetMoby->bSphere;
				recording->pos       = ratchetMoby->pos;
				recording->rMtx      = ratchetMoby->rMtx;
                recording->rot       = ratchetMoby->rot;
				recording->animSeqId = ratchetMoby->animSeqId;
				
				syscall(sys_fs_write, f_recording.fd, recording, sizeof(ghostFile), &f_recording.nread);
				
				// Playback PB ghost if it exists
				if(f_playback.fd) {
					// Init ghost on spawn
					if(!ghostMoby) {
						if (ghostInit() < 0) {
                            return;
                        }
					}
					
					ghostPlayback(ghostMoby, g_Frame);

					// stop temp file recording if playback is done
					if(f_playback.fd == 0) {
						syscall(sys_fs_close, f_recording.fd);
						f_recording.fd = 0;
						ghostState = STATE_STOP;
						savePbState = 0;
						ghostMoby = 0;
					}
				}
			}
			else {
				// empty frame at the end of our file, and add eof indicator
				ghostFile eofFrame = {0};
				eofFrame.eof = 0xDEADDEAD;
				syscall(sys_fs_write, f_recording.fd, &eofFrame, sizeof(ghostFile), &f_recording.nread);
				syscall(sys_fs_close, f_recording.fd);
				f_recording.fd = 0;
				
				if(f_playback.fd) {
					syscall(sys_fs_close, f_playback.fd);
					f_playback.fd = 0;
				}
				
				// only save new pb if we beat the old time
				if (pbTime == 0 || worldUpdateTime < pbTime) {
					savePBWithTime(worldUpdateTime, currentLevel, currentMission);
				}
				
				// and we're done!
				ghostState = STATE_STOP;
				savePbState = 0;
				ghostMoby = 0;
			}
			break;
	}
}

////////////////////////////////////////////////////////////////////////////////
// Logic
////////////////////////////////////////////////////////////////////////////////

void resetPlayback() {
    reserve_stack(512);
    cleanupFiles();

    // need to reset this everytime we load a level.
    pbTime = 0;
    
    // format pb path for planet were on
    sprintf(pbPath, PB_PATH_FORMAT, currentLevel, currentMission);
    
    syscall(sys_fs_open, TEMP_RECORD_PATH, WRITE_FLAGS, &f_recording.fd, 0, 0, 0); 
    syscall(sys_fs_open, pbPath, READ_ONLY_FLAGS, &f_playback.fd, 0, 0, 0);

    // read from file we just opened :3
    if(f_playback.fd >= 0) {
        syscall(sys_fs_read, f_playback.fd, &pbTime, sizeof(int), &f_playback.nread);
    } else {
        pbTime = 0;
    }
    
    ghostState = STATE_RECORD; 
}

void fillEndscreen() {
    // needsDrawing = 1;
    // Fill in custom endscreen info
    sprintf((char*)0x48A4DBA4, "\x12 Clear");
    generate_timer(HCD.vStats[1].zVal, pbTime);
    // Clear remaining elements
    HCD.vStats[2].iVal = 0;
    HCD.vStats[3].iVal = 0;
    // Blank text elements
    sprintf((char*)0x48A3EFC5, "BEST");
    sprintf((char*)0x48A2C146, "");
    sprintf((char*)0x48A3A98E, "");
}

void mainLoop() {
    reserve_stack(512);

    if (gameMode == GAME_MODE_NORMAL && worldUpdateTime == 3) {
        ghostMoby = 0;
        resetPlayback();
    } else if (gameMode == GAME_MODE_FREEZE && HCD.iShown) {
        fillEndscreen();
        if (ghostState == STATE_RECORD && !savePbState) {
            savePbState = 1;
        } else if (ghostState == STATE_STOP && pressedButtons & 16) {
            syscall(sys_fs_unlink, pbPath);
            pbTime = 0;
        }        
    }

    ghostRun();

    return;
}