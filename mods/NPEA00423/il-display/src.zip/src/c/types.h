typedef unsigned char undefined;
typedef unsigned char byte;
typedef unsigned int dword;
typedef long long longlong;
typedef unsigned long long qword;
typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned long long ulonglong;
typedef unsigned char undefined1;
typedef unsigned short undefined2;
typedef unsigned int undefined4;
typedef unsigned long long undefined8;
typedef unsigned short ushort;
typedef unsigned short word;
typedef struct Moby Moby, *PMoby;
typedef unsigned char    bool;


/* WARNING! conflicting data type names: /eboot.bin.h/uchar - /uchar */

typedef uchar uint8_t;

typedef char __int8_t;

typedef __int8_t int8_t;


/* WARNING! conflicting data type names: /types.h/ushort - /ushort */

typedef ushort __uint16_t;

typedef __uint16_t uint16_t;

typedef ulonglong uint64_t;

typedef uint uint32_t;

typedef int int32_t;

typedef enum FontAlignment {
    TOP_LEFT=0,
    TOP_CENTER=1,
    TOP_RIGHT=2,
    CENTER_LEFT=3,
    CENTER_CENTER=4,
    CENTER_RIGHT=5,
    BOTTOM_LEFT=6,
    BOTTOM_CENTER=7,
    BOTTOM_RIGHT=8
} FontAlignment;

